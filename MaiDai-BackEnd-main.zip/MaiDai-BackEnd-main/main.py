from fastapi import FastAPI, HTTPException
from motor.motor_asyncio import AsyncIOMotorClient
import pika
import json
import os
from bson import ObjectId
from typing import List
from pydantic import BaseModel
from fastapi.middleware.cors import CORSMiddleware
import threading

app = FastAPI()

# Configurações do RabbitMQ
rabbitmq_user = 'fazenda'
rabbitmq_password = 'steffenthanos2020'
rabbitmq_host = os.getenv('RABBITMQ_HOST', 'k3s.cos.ufrj.br')
rabbitmq_queue = os.getenv('RABBITMQ_QUEUE', '/FAZENDA')

# Configurações do MongoDB (substitua `MongoClient` por `AsyncIOMotorClient`)
mongo_uri = 'mongodb+srv://maidai:123maidai456@maidai.e3qdm2x.mongodb.net/?retryWrites=true&w=majority&appName=MaiDai'
mongo_db = 'MaiDai'
mongo_collection = 'uva'

# Conectar ao MongoDB de forma assíncrona
mongo_client = AsyncIOMotorClient(mongo_uri)
db = mongo_client[mongo_db]
collection = db[mongo_collection]

# Função para processar mensagens do RabbitMQ
def callback(ch, method, properties, body):
    # Decodificar a mensagem
    message = body.decode('utf-8')
    umidade, id_sensor, coleta_d, coleta_h = message.split()

    # Criar o documento a ser inserido
    document = {
        'umidade': float(umidade),
        'id_sensor': int(id_sensor),
        'data': coleta_d,
        'hora': coleta_h
    }

    # Inserir no MongoDB
    db[mongo_collection].insert_one(document)
    print(f"Mensagem inserida no MongoDB: {document}")

# Configurações da conexão RabbitMQ
credentials = pika.PlainCredentials(rabbitmq_user, rabbitmq_password)
connection = pika.BlockingConnection(pika.ConnectionParameters(host=rabbitmq_host, credentials=credentials))
channel = connection.channel()
channel.queue_declare(queue=rabbitmq_queue)
channel.basic_consume(queue=rabbitmq_queue, on_message_callback=callback, auto_ack=True)

# Iniciar o consumo de mensagens
def start_consuming():
    print('Iniciando o consumo de mensagens...')
    channel.start_consuming()

@app.on_event("startup")
async def startup_event():
    consumer_thread = threading.Thread(target=start_consuming)
    consumer_thread.daemon = True
    consumer_thread.start()

@app.get("/")
def read_root():
    return {"message": "API está funcionando e consumindo mensagens do RabbitMQ"}

# Modelo Pydantic para dados
class Reading(BaseModel):
    umidade: float
    id_sensor: int
    data: str
    hora: str

# Serializar para ObjectId
def serialize_reading(reading):
    return {
        "_id": str(reading["_id"]),
        "umidade": reading["umidade"],
        "id_sensor": reading["id_sensor"],
        "data": reading["data"],
        "hora": reading["hora"]
    }

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Pegar todas as medidas do sensor
@app.get("/readings", response_model=List[Reading])
async def get_readings():
    readings = []
    async for reading in collection.find():
        readings.append(serialize_reading(reading))
    if not readings:
        raise HTTPException(status_code=404, detail="No readings found")
    return readings

# Pegar uma medida específica por ID
@app.get("/readings/{reading_id}", response_model=Reading)
async def get_reading(reading_id: str):
    reading = await collection.find_one({"_id": ObjectId(reading_id)})
    if not reading:
        raise HTTPException(status_code=404, detail="Reading not found")
    return serialize_reading(reading)

# Pegar todas as leituras para um id_sensor específico
@app.get("/readings/sensor/{id_sensor}", response_model=List[Reading])
async def get_readings_by_sensor(id_sensor: int):
    readings = []
    async for reading in collection.find({"id_sensor": id_sensor}):
        readings.append(serialize_reading(reading))
    if not readings:
        raise HTTPException(status_code=404, detail="No readings found for the given sensor ID")
    return readings

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
