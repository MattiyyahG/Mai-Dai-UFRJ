# FastAPI RabbitMQ-MongoDB Integration

Este projeto é uma aplicação FastAPI que consome mensagens de uma fila RabbitMQ e as armazena em um banco de dados MongoDB. O objetivo é processar dados de umidade de sensores e armazená-los de forma estruturada.

## Tecnologias Utilizadas

- **FastAPI**: Framework web em Python para criar APIs rápidas e eficientes.
- **RabbitMQ**: Broker de mensagens usado para a comunicação entre sistemas.
- **MongoDB**: Banco de dados NoSQL usado para armazenar os dados coletados.
- **Pika**: Biblioteca Python para interagir com o RabbitMQ.

## Funcionalidades

- Conecta-se a um broker RabbitMQ para consumir mensagens de uma fila específica.
- Processa cada mensagem recebida, que contém dados de umidade, ID do sensor, data e hora da coleta.
- Armazena os dados processados no MongoDB em uma coleção especificada.
- Disponibiliza uma rota simples (`GET /`) para verificar se a API está ativa.

## Configuração

### Pré-requisitos

- **Python 3.8+**
- **MongoDB Atlas** (ou outro servidor MongoDB)
- **RabbitMQ** instalado e configurado

### Instalação

1. Clone este repositório:
   ```bash
   git clone https://github.com/seu_usuario/nome_do_repositorio.git
   cd nome_do_repositorio
   ```

2. Crie um ambiente virtual e ative-o:
   ```bash
   python3 -m venv venv
   source venv/bin/activate  # No Windows, use 'venv\Scripts\activate'
   ```

3. Instale as dependências:
   ```bash
   pip install -r requirements.txt
   ```

### Configuração de Variáveis de Ambiente

Crie um arquivo `.env` na raiz do projeto para armazenar as variáveis de ambiente necessárias:

```env
RABBITMQ_HOST=host.docker.internal  # Substitua conforme necessário
RABBITMQ_QUEUE=sensor_data_queue  # Substitua conforme necessário
```

Certifique-se de atualizar as configurações de conexão do MongoDB e RabbitMQ no código conforme necessário:

- **RabbitMQ**:
  - Usuário: `fazenda`
  - Senha: `steffenthanos2020`
  - Host: configurável via variável de ambiente `RABBITMQ_HOST`
  - Fila: configurável via variável de ambiente `RABBITMQ_QUEUE`

- **MongoDB**:
  - URI: Substitua o valor de `mongo_uri` pelo URI da sua instância do MongoDB.

### Executando a Aplicação

Inicie a aplicação usando o Uvicorn:

```bash
uvicorn main:app --host 0.0.0.0 --port 8000
```

A aplicação estará disponível em `http://localhost:8000`.

### Estrutura das Mensagens

As mensagens enviadas para o RabbitMQ devem ter o seguinte formato:

```
<umidade> <id_sensor> <data> <hora>
```

- **umidade**: Valor numérico da umidade (ex.: `45.2`)
- **id_sensor**: ID do sensor (ex.: `101`)
- **data**: Data da coleta (ex.: `2023-10-09`)
- **hora**: Hora da coleta (ex.: `14:35`)

### Rota Disponível

- `GET /`: Verifica se a API está funcionando e consumindo mensagens do RabbitMQ.

## Notas de Segurança

⚠️ **Importante:** Não inclua credenciais sensíveis no código-fonte ou em repositórios públicos. Utilize variáveis de ambiente ou serviços de gerenciamento de segredos para armazenar informações confidenciais.

## Contribuição

Sinta-se à vontade para contribuir com este projeto. Basta fazer um fork do repositório, criar uma branch para suas alterações e enviar um pull request.

1. Faça um fork do repositório.
2. Crie uma branch com a sua feature:
   ```bash
   git checkout -b minha-feature
   ```
3. Commit suas alterações:
   ```bash
   git commit -m 'Minha nova feature'
   ```
4. Envie para o repositório remoto:
   ```bash
   git push origin minha-feature
   ```
5. Abra um pull request.

---

## Imagens Docker

As imagens Docker necessárias para este projeto estão disponíveis no Docker Hub sob o repositório `mattiyyah`. Abaixo estão as imagens e os comandos para baixá-las:

1. **RabbitMQ**: [mattiyyah/rabbitmq](https://hub.docker.com/r/mattiyyah/rabbitmq)
2. **MongoDB**: [mattiyyah/mongodb](https://hub.docker.com/r/mattiyyah/mongodb)
3. **Fazenda App**: [mattiyyah/fazenda-app](https://hub.docker.com/r/mattiyyah/fazenda-app)

### Como Baixar as Imagens

Para baixar cada uma das imagens, execute os seguintes comandos:

```bash
# Baixar a imagem RabbitMQ
docker pull mattiyyah/rabbitmq

# Baixar a imagem MongoDB
docker pull mattiyyah/mongodb

# Baixar a imagem da aplicação Fazenda App
docker pull mattiyyah/fazenda-app
```

### Como Executar os Contêineres

Após baixar as imagens, você pode executar cada contêiner com os seguintes comandos:

1. **Executar RabbitMQ**:
   ```bash
   docker run -d --name rabbitmq -p 5672:5672 -p 15672:15672 mattiyyah/rabbitmq
   ```

   - Expor a porta `5672` para comunicação e `15672` para acessar o RabbitMQ Management UI.

2. **Executar MongoDB**:
   ```bash
   docker run -d --name mongodb -p 27017:27017 mattiyyah/mongodb
   ```

   - Expor a porta `27017` para acessar o banco de dados MongoDB.

3. **Executar a aplicação Fazenda App**:
   ```bash
   docker run -d --name fazenda-app -p 8000:8000 --env RABBITMQ_HOST=<seu_host> --env RABBITMQ_QUEUE=<sua_fila> mattiyyah/fazenda-app
   ```

   - Substitua `<seu_host>` pelo endereço do host RabbitMQ e `<sua_fila>` pelo nome da fila desejada.
   - Expor a porta `8000` para acessar a API.

### Verificando a Execução

Após iniciar os contêineres, você pode verificar se estão em execução com o comando:

```bash
docker ps
```

Isso mostrará uma lista de todos os contêineres em execução e suas respectivas portas.

### Ordem Recomendada de Inicialização

1. Inicie o contêiner do **MongoDB**.
2. Em seguida, inicie o **RabbitMQ**.
3. Por último, inicie o contêiner da aplicação **Fazenda App** para que ele possa se conectar corretamente ao RabbitMQ e ao MongoDB.

---

Isso ajudará a configurar e executar o ambiente do projeto usando contêineres Docker, garantindo que todos os serviços estejam devidamente configurados e rodando.

## Licença

Este projeto está licenciado sob a licença MIT. Veja o arquivo `LICENSE` para mais detalhes.

---

Substitua os placeholders como `seu_usuario` e `nome_do_repositorio` conforme necessário. Este README cobre desde a descrição do projeto até as instruções de instalação e execução, facilitando para outros desenvolvedores entenderem e configurarem o projeto.
